import { DemodirectiveDirective } from './demodirective.directive';

describe('DemodirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DemodirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
